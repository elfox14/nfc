<?php
/**
 * MC PRIME NFC - Upload Configuration
 * 
 * ⚠️ هذا الملف يحتوي على الإعدادات السرية
 * ⚠️ لا ترفعه على Git — تأكد أنه في .gitignore
 * ⚠️ ارفعه يدوياً على سيرفر uploads.mcprim.com فقط
 * 
 * تعليمات:
 * 1. غيّر UPLOAD_SECRET لمفتاح جديد قوي
 * 2. نفس المفتاح يجب أن يكون في .env على سيرفر Render
 * 3. ارفع هذا الملف بجانب upload.php على الاستضافة
 */

return [
    // المفتاح السري — يجب أن يطابق UPLOAD_SECRET في .env على سيرفر Render
    'UPLOAD_SECRET' => 'mcprime_upload_secret_1986_xK8nP2vL',

    // الدومينات المسموح لها بالرفع
    'ALLOWED_ORIGINS' => [
        'https://mcprim.com',
        'https://www.mcprim.com',
        'https://mcprim-nfc.onrender.com',
    ],

    // الرابط الأساسي لمجلد الصور
    'BASE_URL' => 'https://uploads.mcprim.com/uploads',
];
