/**
 * @jest-environment node
 */
const request = require('supertest');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Note: Redis mock removed — server.js does not use Redis.

// Mock MongoDB
const mockCollection = {
    findOne: jest.fn(),
    insertOne: jest.fn(),
    updateOne: jest.fn(),
    deleteOne: jest.fn(),
    createIndex: jest.fn(),
    countDocuments: jest.fn()
};

const mockDb = {
    collection: jest.fn(() => mockCollection),
    command: jest.fn(() => Promise.resolve({ ok: 1 }))
};

const mockClient = {
    db: jest.fn(() => mockDb)
};

jest.mock('mongodb', () => ({
    MongoClient: {
        connect: jest.fn().mockResolvedValue(mockClient)
    }
}));

jest.setTimeout(30000);

// Setup Test Environment Variables
process.env.NODE_ENV = 'test';
// SECURITY: Use a strong random secret for each test run (never hardcode secrets)
process.env.JWT_SECRET = require('crypto').randomBytes(32).toString('hex');
process.env.MONGO_URI = 'mongodb://fake-uri';
process.env.PUBLIC_BASE_URL = 'http://localhost:3000';

const app = require('../server.js');

describe('Auth Integration Tests (Ticket 9)', () => {

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('POST /api/auth/register', () => {
        it('Should register a new user successfully', async () => {
            // Setup Mock: No existing user found
            mockCollection.findOne.mockResolvedValueOnce(null);
            mockCollection.insertOne.mockResolvedValueOnce({ insertedId: '123' });
            mockCollection.updateOne.mockResolvedValueOnce({ matchedCount: 1 });

            const res = await request(app)
                .post('/api/auth/register')
                .send({ name: 'Test User', email: 'test@example.com', password: 'password123' });

            expect(res.status).toBe(201);
            expect(res.body.success).toBe(true);
            expect(jwt.verify(res.body.accessToken, process.env.JWT_SECRET)).toMatchObject({
                email: 'test@example.com',
                type: 'access'
            });
            expect(res.body.user.email).toBe('test@example.com');

            // Check if HttpOnly auth cookies are set
            const cookies = res.headers['set-cookie'];
            expect(cookies).toBeDefined();
            expect(cookies.some(c => c.includes('accessToken='))).toBeTruthy();
            expect(cookies.some(c => c.includes('refreshToken='))).toBeTruthy();
        });

        it('Should reject duplicate emails', async () => {
            // Setup Mock: Existing user found
            mockCollection.findOne.mockResolvedValueOnce({ email: 'test@example.com' });

            const res = await request(app)
                .post('/api/auth/register')
                .send({ name: 'Test User 2', email: 'test@example.com', password: 'password123' });

            expect(res.status).toBe(400);
            expect(res.body.error).toBe('User already exists');
        });
    });

    describe('POST /api/auth/login', () => {
        it('Should log in user with correct credentials', async () => {
            // Hash a fake password to match
            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash('password123', salt);

            // Setup Mock
            mockCollection.findOne.mockResolvedValueOnce({
                userId: 'u123',
                email: 'test@example.com',
                name: 'Test user',
                password: hashedPassword
            });
            mockCollection.insertOne.mockResolvedValueOnce({ insertedId: 'r123' });

            const res = await request(app)
                .post('/api/auth/login')
                .send({ email: 'test@example.com', password: 'password123' });

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);
            expect(jwt.verify(res.body.accessToken, process.env.JWT_SECRET)).toMatchObject({
                userId: 'u123',
                type: 'access'
            });

            const cookies = res.headers['set-cookie'];
            expect(cookies).toBeDefined();
            expect(cookies.some(c => c.includes('accessToken='))).toBeTruthy();
            expect(cookies.some(c => c.includes('refreshToken='))).toBeTruthy();
        });

        it('Should reject incorrect password', async () => {
            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash('password123', salt);

            mockCollection.findOne.mockResolvedValueOnce({
                userId: 'u123',
                email: 'test@example.com',
                password: hashedPassword
            });

            const res = await request(app)
                .post('/api/auth/login')
                .send({ email: 'test@example.com', password: 'wrongpassword' });

            expect(res.status).toBe(400);
            expect(res.body.error).toBe('Invalid credentials');
        });
    });

    describe('POST /api/auth/refresh', () => {
        it('Should prevent token refresh without a valid cookie payload', async () => {
            const res = await request(app).post('/api/auth/refresh');
            expect(res.status).toBe(401);
            expect(res.body.error).toBe('No refresh token provided');
        });

        it('Should reject malformed refresh tokens before database lookup', async () => {
            const res = await request(app)
                .post('/api/auth/refresh')
                .set('Cookie', ['refreshToken=not-a-valid-token']);

            expect(res.status).toBe(403);
            expect(mockCollection.findOne).not.toHaveBeenCalled();
        });

        // In a full environment, we would inject a mapped cookie matching mockCollection.findOne.
    });

    describe('POST /api/auth/session-init', () => {
        it('exchanges a one-time Google init token for a short-lived access token', async () => {
            const initToken = jwt.sign(
                { userId: 'u-google', email: 'google@example.com', type: 'session-init' },
                process.env.JWT_SECRET,
                { expiresIn: '60s' }
            );
            mockCollection.updateOne.mockResolvedValueOnce({ matchedCount: 1 });
            mockCollection.findOne.mockResolvedValueOnce({
                userId: 'u-google', email: 'google@example.com', name: 'Google User'
            });

            const res = await request(app)
                .post('/api/auth/session-init')
                .send({ initToken });

            expect(res.status).toBe(200);
            expect(jwt.verify(res.body.accessToken, process.env.JWT_SECRET)).toMatchObject({
                userId: 'u-google', type: 'access'
            });
            expect(mockCollection.updateOne.mock.calls[0][0]).toMatchObject({
                userId: 'u-google',
                sessionInitTokenExpiry: { $gt: expect.any(Date) }
            });
        });

        it('rejects replay of an already-consumed init token', async () => {
            const initToken = jwt.sign(
                { userId: 'u-google', email: 'google@example.com', type: 'session-init' },
                process.env.JWT_SECRET,
                { expiresIn: '60s' }
            );
            mockCollection.updateOne
                .mockResolvedValueOnce({ matchedCount: 1 })
                .mockResolvedValueOnce({ matchedCount: 0 });
            mockCollection.findOne.mockResolvedValueOnce({
                userId: 'u-google', email: 'google@example.com', name: 'Google User'
            });

            const first = await request(app).post('/api/auth/session-init').send({ initToken });
            const replay = await request(app).post('/api/auth/session-init').send({ initToken });

            expect(first.status).toBe(200);
            expect(replay.status).toBe(401);
        });
    });

    describe('POST /api/auth/reset-password', () => {
        it('Should reject malformed reset tokens before database lookup', async () => {
            const res = await request(app)
                .post('/api/auth/reset-password')
                .send({ token: 'bad-token', password: 'password123' });

            expect(res.status).toBe(400);
            expect(mockCollection.findOne).not.toHaveBeenCalled();
        });
    });

    describe('POST /api/auth/verify-email', () => {
        it('Should reject malformed verification tokens before database lookup', async () => {
            const res = await request(app)
                .post('/api/auth/verify-email')
                .send({ token: 'bad-token' });

            expect(res.status).toBe(400);
            expect(mockCollection.findOne).not.toHaveBeenCalled();
        });
    });

    describe('Origin protection', () => {
        it('Should reject unsafe API requests from disallowed origins', async () => {
            const res = await request(app)
                .post('/api/auth/login')
                .set('Origin', 'https://evil.example')
                .send({ email: 'test@example.com', password: 'password123' });

            expect(res.status).toBe(403);
            expect(mockCollection.findOne).not.toHaveBeenCalled();
        });
    });

    describe('POST /api/auth/logout', () => {
        it('Should clear the HttpOnly refreshToken cookie', async () => {
            mockCollection.deleteOne.mockResolvedValueOnce({ deletedCount: 1 });

            const res = await request(app)
                .post('/api/auth/logout')
                .set('Cookie', [`refreshToken=mocked_fake_token_value`]);

            expect(res.status).toBe(200);
            expect(res.body.success).toBe(true);

            const cookies = res.headers['set-cookie'];
            expect(cookies.some(c => c.includes('refreshToken=;'))).toBeTruthy();
        });
    });
});
