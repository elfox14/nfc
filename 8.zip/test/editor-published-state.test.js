/**
 * @jest-environment node
 */

'use strict';

const fs = require('fs');
const path = require('path');

describe('Editor published-state contract', () => {
    const source = fs.readFileSync(path.join(__dirname, '..', 'script-main.original.js'), 'utf8');
    const userStatusSource = fs.readFileSync(path.join(__dirname, '..', 'editor-user-status.original.js'), 'utf8');
    const editorAr = fs.readFileSync(path.join(__dirname, '..', 'editor.html'), 'utf8');
    const editorEn = fs.readFileSync(path.join(__dirname, '..', 'editor-en.html'), 'utf8');

    test('publishing snapshots the exact state used for both captured faces', () => {
        expect(source).toContain('shareState.publishedState = this.createPublishedState(shareState);');
        expect(source.indexOf('shareState.imageUrls.capturedBack = backImageUrl;'))
            .toBeLessThan(source.indexOf('shareState.publishedState = this.createPublishedState(shareState);'));
        expect(source.indexOf('shareState.publishedState = this.createPublishedState(shareState);'))
            .toBeLessThan(source.indexOf('const designId = await this.saveDesign(shareState);'));
    });

    test('dashboard edit restores the published revision by default', () => {
        expect(source).toContain("const wantsDraft = params.get('mode') === 'draft';");
        expect(source).toContain('const state = !wantsDraft && hasPublishedState');
        expect(source).toContain('? storedState.publishedState');
    });

    test('the actual toolbar save path publishes the captured editable state', () => {
        expect(userStatusSource).toContain('state.publishedState = ShareManager.createPublishedState(state);');
        expect(userStatusSource.indexOf('state.imageUrls.capturedBack = backImageUrl;'))
            .toBeLessThan(userStatusSource.indexOf('state.publishedState = ShareManager.createPublishedState(state);'));
        expect(userStatusSource.indexOf('state.publishedState = ShareManager.createPublishedState(state);'))
            .toBeLessThan(userStatusSource.indexOf('const designId = await ShareManager.saveDesign(state);'));
    });

    test('shared editor links explicitly request the draft revision', () => {
        expect(source).toContain("editorUrl.searchParams.set('mode', 'draft');");
        expect(source).toContain('? `/api/get-design/${designId}/draft`');
    });

    test('the public viewer prefers a published snapshot defensively', () => {
        const viewerSource = fs.readFileSync(path.join(__dirname, '..', 'viewer.original.js'), 'utf8');
        expect(viewerSource).toContain('function selectPublishedCardData(data)');
        expect(viewerSource).toContain('data = selectPublishedCardData(data);');
    });

    test('both editor languages load the cache-busted implementation', () => {
        expect(editorAr).toContain('script-main.js?v=2.5');
        expect(editorEn).toContain('script-main.js?v=2.5');
        expect(editorAr).toContain('editor-user-status.js?v=1.1');
        expect(editorEn).toContain('editor-user-status.js?v=1.1');
    });
});
