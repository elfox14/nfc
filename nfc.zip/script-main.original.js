'use strict';

// Language detection and i18n for script-main.js (computed once at load)
const _isEnglishPage = document.documentElement.lang === 'en';

// Custom confirm dialog with نعم/لا (Yes/No) buttons
function customConfirm(message) {
    return new Promise((resolve) => {
        const overlay = document.createElement('div');
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:99999;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px);';
        const box = document.createElement('div');
        box.style.cssText = 'background:#1c2a3b;border:1px solid rgba(77,166,255,0.2);border-radius:16px;padding:30px;max-width:400px;width:90%;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,0.5);';
        const msg = document.createElement('p');
        msg.textContent = message;
        msg.style.cssText = 'color:#fff;font-size:1.1rem;margin:0 0 25px;line-height:1.6;font-family:Tajawal,sans-serif;';
        const btns = document.createElement('div');
        btns.style.cssText = 'display:flex;gap:12px;justify-content:center;';
        const yesBtn = document.createElement('button');
        yesBtn.textContent = _isEnglishPage ? 'Yes' : 'نعم';
        yesBtn.style.cssText = 'padding:10px 32px;border-radius:10px;border:none;cursor:pointer;font-size:1rem;font-weight:700;font-family:inherit;background:#4da6ff;color:#fff;transition:background 0.2s;';
        yesBtn.onmouseenter = () => yesBtn.style.background = '#3d8fe6';
        yesBtn.onmouseleave = () => yesBtn.style.background = '#4da6ff';
        const noBtn = document.createElement('button');
        noBtn.textContent = _isEnglishPage ? 'No' : 'لا';
        noBtn.style.cssText = 'padding:10px 32px;border-radius:10px;border:1px solid rgba(255,255,255,0.2);cursor:pointer;font-size:1rem;font-weight:700;font-family:inherit;background:transparent;color:#fff;transition:background 0.2s;';
        noBtn.onmouseenter = () => noBtn.style.background = 'rgba(255,255,255,0.1)';
        noBtn.onmouseleave = () => noBtn.style.background = 'transparent';
        btns.appendChild(yesBtn);
        btns.appendChild(noBtn);
        box.appendChild(msg);
        box.appendChild(btns);
        overlay.appendChild(box);
        document.body.appendChild(overlay);
        yesBtn.onclick = () => { overlay.remove(); resolve(true); };
        noBtn.onclick = () => { overlay.remove(); resolve(false); };
    });
}
const i18nMain = {
    galleryPrompt: _isEnglishPage ? 'Would you like to display your design in the gallery page?' : 'هل تريد عرض تصميمك في صفحة المعرض؟',
    capturing: _isEnglishPage ? 'Capturing...' : 'جاري الالتقاط...',
    uploading: _isEnglishPage ? 'Uploading images...' : 'جاري رفع الصور...',
    generating: _isEnglishPage ? 'Generating link...' : 'جاري إنشاء الرابط...',
    captureError: _isEnglishPage ? 'Failed to capture or upload card image. Please try again.' : 'فشل التقاط أو رفع صورة البطاقة. يرجى المحاولة مرة أخرى.',
    saveError: _isEnglishPage ? 'Failed to save design. Please try again.' : 'فشل حفظ التصميم. يرجى المحاولة مرة أخرى.',
    linkCopied: _isEnglishPage ? 'Link copied to clipboard!' : 'تم نسخ الرابط!',
    shareTitle: _isEnglishPage ? 'My Digital Business Card' : 'بطاقة العمل الرقمية الخاصة بي',
    shareText: _isEnglishPage ? 'Check out my digital business card:' : 'اطلع على بطاقتي الرقمية:',
    copyLinkFailed: _isEnglishPage ? 'Could not copy link automatically. Please copy it manually.' : 'لم نتمكن من نسخ الرابط تلقائياً. يرجى نسخه يدوياً.',
    designSaved: _isEnglishPage ? 'Design saved to gallery successfully!' : 'تم حفظ التصميم في المعرض بنجاح!',
    saveGalleryError: _isEnglishPage ? 'Failed to save design to gallery. There might be a problem loading components.' : 'فشل حفظ التصميم في المعرض. قد تكون هناك مشكلة في تحميل المكونات اللازمة.',
    confirmDelete: _isEnglishPage ? 'Are you sure you want to delete "{name}"?' : 'هل أنت متأكد من حذف "{name}"؟',
    galleryEmpty: _isEnglishPage ? 'The gallery is empty. Save your current design to start.' : 'المعرض فارغ. قم بحفظ تصميمك الحالي للبدء.',
    load: _isEnglishPage ? 'Load' : 'تحميل',
    designLoaded: _isEnglishPage ? 'Design loaded from link successfully.' : 'تم تحميل التصميم من الرابط بنجاح.',
    designRestored: _isEnglishPage ? 'Saved design restored.' : 'تم استعادة التصميم المحفوظ.',
    defaultLoaded: _isEnglishPage ? 'Default design loaded.' : 'تم تحميل التصميم الافتراضي.',
    creating: _isEnglishPage ? 'Creating...' : 'جاري الإنشاء...',
};

const CollaborationManager = {
    ws: null,
    collabId: null,
    inviteToken: null,
    isActive: false,

    init() {
        // Collaboration secrets live in the fragment so they are never sent
        // in HTTP requests, Referer headers, or server access logs.
        const fragment = new URLSearchParams(window.location.hash.replace(/^#/, ''));
        this.collabId = fragment.get('collabId');
        this.inviteToken = fragment.get('invite');

        if (this.collabId && this.inviteToken) {
            window.history.replaceState({}, '', `${window.location.pathname}${window.location.search}`);
            this.connect(this.collabId, this.inviteToken);
        }

        // 2. ربط الأحداث بالأزرار والمودال
        const startBtn = document.getElementById('start-collab-btn');
        const modalOverlay = document.getElementById('collab-modal-overlay');
        const closeBtn = document.getElementById('collab-modal-close');
        const copyBtn = document.getElementById('copy-collab-link-btn');

        if (startBtn) startBtn.addEventListener('click', () => this.startSession());
        if (closeBtn) closeBtn.addEventListener('click', () => UIManager.hideModal(modalOverlay));
        if (copyBtn) copyBtn.addEventListener('click', () => this.copyLink());
    },

    async startSession() {
        const startBtn = document.getElementById('start-collab-btn');
        UIManager.setButtonLoadingState(startBtn, true, i18nMain.creating);
        try {
            // 3. احفظ التصميم للحصول على ID فريد
            const designId = await ShareManager.saveDesign();
            if (!designId) {
                throw new Error(_isEnglishPage ? 'Failed to save design for session.' : 'فشل حفظ التصميم لإنشاء جلسة.');
            }
            const inviteResponse = await Auth.apiFetchWithRefresh(
                `${Config.API_BASE_URL}/api/auth/collaboration-invite`,
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ designId })
                }
            );
            const invitation = await inviteResponse.json();
            if (!inviteResponse.ok || !invitation.success) {
                throw new Error(invitation.error || (_isEnglishPage ? 'Failed to create secure invitation.' : 'فشل إنشاء دعوة آمنة.'));
            }
            this.collabId = invitation.collabId;
            this.inviteToken = invitation.invite;

            // 4. أنشئ الرابط واعرضه في المودال
            const collabUrl = new URL(window.location.origin + window.location.pathname);
            collabUrl.hash = new URLSearchParams({
                collabId: this.collabId,
                invite: this.inviteToken
            }).toString();

            document.getElementById('collab-link-input').value = collabUrl.href;
            UIManager.showModal(document.getElementById('collab-modal-overlay'));

            // 5. اتصل بالـ WebSocket
            this.connect(this.collabId, this.inviteToken);

        } catch (error) {
            console.error("Failed to start collaboration session:", error);
            alert(error.message);
        } finally {
            UIManager.setButtonLoadingState(startBtn, false);
        }
    },

    connect(collabId, inviteToken) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            return; // متصل بالفعل
        }

        const apiUrl = new URL(Config.API_BASE_URL);
        const protocol = apiUrl.protocol === 'https:' ? 'wss:' : 'ws:';
        // Only the random room identifier is visible during the WS upgrade.
        const wsUrl = `${protocol}//${apiUrl.host}?collabId=${encodeURIComponent(collabId)}`;

        this.ws = new WebSocket(wsUrl);

        this.ws.onopen = async () => {
            console.log('WebSocket connection opened, fetching auth token...');
            try {
                // Exchange the fragment-only invitation for a room-bound token.
                const res = await Auth.apiFetchWithRefresh(
                    `${Config.API_BASE_URL}/api/auth/ws-token`,
                    {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ collabId, invite: inviteToken })
                    }
                );
                const data = await res.json();
                if (data.success && data.token) {
                    this.ws.send(JSON.stringify({ type: 'auth', token: data.token }));
                } else {
                    console.error('WebSocket: Failed to get auth token');
                    this.ws.close(1008, 'No auth token');
                }
            } catch (err) {
                console.error('WebSocket: Auth token fetch failed:', err);
                this.ws.close(1008, 'Auth token fetch failed');
            }
        };

        this.ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);

                // Handle auth response
                if (data.type === 'auth') {
                    if (data.success) {
                        console.log('WebSocket authenticated and connected for collaboration.');
                        this.isActive = true;
                        this.updateStatus('متصل');
                        document.body.classList.add('collaboration-active');
                        if (data.role === 'owner') {
                            this.sendState(StateManager.getStateObject());
                        }
                    } else {
                        console.error('WebSocket authentication failed');
                        this.updateStatus('فشل المصادقة');
                    }
                    return;
                }

                if (data.type === 'state' && data.state) {
                    console.log('Received state from collaborator.');
                    StateManager.applyState(data.state, false);
                }
            } catch (error) {
                console.error('Error processing incoming message:', error);
            }
        };

        this.ws.onclose = () => {
            console.log('WebSocket connection closed.');
            this.isActive = false;
            this.ws = null;
            this.updateStatus('غير متصل');
            document.body.classList.remove('collaboration-active');
        };

        this.ws.onerror = (error) => {
            console.error('WebSocket error:', error);
            this.isActive = false;
            this.updateStatus('خطأ في الاتصال');
        };
    },

    sendState(state) {
        // 7. أرسل التحديثات إلى الخادم
        if (this.isActive && this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({ type: 'state', state }));
        }
    },

    updateStatus(message) {
        const statusEl = document.getElementById('collab-status');
        if (statusEl) statusEl.textContent = `الحالة: ${message}`;
    },

    copyLink() {
        const input = document.getElementById('collab-link-input');
        Utils.copyTextToClipboard(input.value).then(success => {
            if (success) {
                UIManager.announce('تم نسخ رابط الجلسة!');
                const copyBtn = document.getElementById('copy-collab-link-btn');
                const originalText = "نسخ";
                copyBtn.textContent = 'تم النسخ ✓';
                setTimeout(() => { copyBtn.textContent = originalText; }, 2000);
            }
        });
    }
};

const ExportManager = {
    pendingExportTarget: null,

    async captureElement(element, scale = 2) {
        await Utils.loadScript(Config.SCRIPT_URLS.html2canvas);
        const style = document.createElement('style');
        style.innerHTML = '.no-export { display: none !important; }';
        document.head.appendChild(style);

        // On mobile, cards-wrapper has a CSS scale transform that breaks html2canvas.
        // Temporarily remove it before capture and restore it afterwards.
        const cardsWrapper = document.getElementById('cards-wrapper');
        const originalWrapperTransform = cardsWrapper ? cardsWrapper.style.transform : '';
        if (cardsWrapper && originalWrapperTransform) cardsWrapper.style.transform = '';

        const isMobile = typeof MobileUtils !== 'undefined' && MobileUtils.isMobile();
        const originalStates = [];

        if (isMobile) {
            const flipper = document.querySelector('.card-flipper');
            const flipperContainer = document.querySelector('.card-flipper-container');
            const faces = document.querySelectorAll('.card-face');
            const isCapturingBack = element.id === 'card-back-preview';
            
            const setProps = (el, props) => {
                if (!el) return;
                const state = { element: el, props: {} };
                for (const [key, value] of Object.entries(props)) {
                    state.props[key] = el.style.getPropertyValue(key);
                    el.style.setProperty(key, value, 'important');
                }
                originalStates.push(state);
            };

            setProps(flipperContainer, {
                'perspective': 'none',
                'transform-style': 'flat',
                'transform': 'none'
            });

            setProps(flipper, {
                'transform-style': 'flat',
                'transform': 'none',
                'transition': 'none'
            });

            faces.forEach(face => {
                const isTargetFace = face.classList.contains('card-front') ? !isCapturingBack : isCapturingBack;
                setProps(face, {
                    'backface-visibility': 'visible',
                    '-webkit-backface-visibility': 'visible',
                    'transform': 'none',
                    'position': 'absolute',
                    'top': '0',
                    'left': '0',
                    'visibility': isTargetFace ? 'visible' : 'hidden',
                    'z-index': isTargetFace ? '10' : '-1'
                });
            });
            
            await new Promise(resolve => setTimeout(resolve, 80));
        }

        try {
            return await html2canvas(element, {
                backgroundColor: null, // Transparent background so border-radius corners don't have black edges
                scale: scale,
                useCORS: true,
                allowTaint: true,
                logging: false,
                scrollX: 0,
                scrollY: 0,
                windowWidth: 1400,
                windowHeight: 900
            });
        }
        finally {
            document.head.removeChild(style);
            // Restore the mobile scale transform
            if (cardsWrapper && originalWrapperTransform) cardsWrapper.style.transform = originalWrapperTransform;
            
            // Restore 3D states
            for (let i = originalStates.length - 1; i >= 0; i--) {
                const { element: el, props } = originalStates[i];
                for (const [key, value] of Object.entries(props)) {
                    if (value) {
                        el.style.setProperty(key, value);
                    } else {
                        el.style.removeProperty(key);
                    }
                }
            }
        }
    },

    async downloadElement(options) {
        const { format, quality, scale } = options;
        const element = this.pendingExportTarget === 'front' ? DOMElements.cardFront : DOMElements.cardBack;
        const filename = `card-${this.pendingExportTarget}.${format}`;

        UIManager.showModal(DOMElements.exportLoadingOverlay);
        try {
            await new Promise(resolve => setTimeout(resolve, 100));
            const canvas = await this.captureElement(element, scale);
            const link = document.createElement('a');
            link.download = filename;
            link.href = canvas.toDataURL(`image/${format}`, quality);
            link.click();
        } catch (e) {
            console.error("Export failed:", e);
            UIManager.announce("فشل التصدير.");
        }
        finally {
            UIManager.hideModal(DOMElements.exportLoadingOverlay);
            UIManager.hideModal(DOMElements.exportModal.overlay);
        }
    },

    async downloadPdf() {
        await Promise.all([
            Utils.loadScript(Config.SCRIPT_URLS.html2canvas),
            Utils.loadScript(Config.SCRIPT_URLS.jspdf)
        ]);
        try {
            const { jsPDF } = window.jspdf;

            const isVertical = DOMElements.cardsWrapper.dataset.layout === 'vertical';
            const width = isVertical ? 330 : 510;
            const height = isVertical ? 510 : 330;
            const orientation = isVertical ? 'p' : 'l';

            const doc = new jsPDF({
                orientation: orientation,
                unit: 'px',
                format: [width, height]
            });

            const frontCanvas = await this.captureElement(DOMElements.cardFront, 2);
            doc.addImage(frontCanvas.toDataURL('image/png'), 'PNG', 0, 0, width, height);

            doc.addPage([width, height], orientation);

            const backCanvas = await this.captureElement(DOMElements.cardBack, 2);
            doc.addImage(backCanvas.toDataURL('image/png'), 'PNG', 0, 0, width, height);

            doc.save('business-card.pdf');
        } catch (e) {
            console.error('PDF export failed:', e);
            UIManager.announce('فشل تصدير PDF.');
        }
    },

    getVCardString() {
        const state = StateManager.getStateObject();
        const lang = state.currentLanguage || 'ar';
        let nameInput = document.getElementById(`input-name_${lang}`);
        let taglineInput = document.getElementById(`input-tagline_${lang}`);

        if (!nameInput) {
            nameInput = document.getElementById('input-name_en') || document.getElementById('input-name_ar');
        }
        if (!taglineInput) {
            taglineInput = document.getElementById('input-tagline_en') || document.getElementById('input-tagline_ar');
        }

        const nameValue = nameInput ? nameInput.value : '';
        const taglineValue = taglineInput ? taglineInput.value : '';

        const name = nameValue.replace(/\n/g, ' ').split(' ');
        const firstName = name.slice(0, -1).join(' ');
        const lastName = name.slice(-1).join(' ');
        let vCard = `BEGIN:VCARD\nVERSION:3.0\nN:${lastName};${firstName};;;\nFN:${nameValue}\nORG:${taglineValue.replace(/\n/g, ' ')}\nTITLE:${taglineValue.replace(/\n/g, ' ')}\n`;

        if (state.dynamic.staticSocial.email && state.dynamic.staticSocial.email.value) {
            vCard += `EMAIL;TYPE=PREF,INTERNET:${state.dynamic.staticSocial.email.value}\n`;
        }
        if (state.dynamic.staticSocial.website && state.dynamic.staticSocial.website.value) {
            vCard += `URL:${state.dynamic.staticSocial.website.value}\n`;
        }

        if (state.dynamic.phones) {
            state.dynamic.phones.forEach((phone, index) => {
                if (phone.value) vCard += `TEL;TYPE=CELL${index === 0 ? ',PREF' : ''}:${phone.value}\n`;
            });
        }

        if (state.dynamic.social) {
            state.dynamic.social.forEach(link => {
                const platformKey = link.platform;
                const value = link.value;
                if (platformKey && value && Config.SOCIAL_PLATFORMS[platformKey]) {
                    let fullUrl = !/^(https?:\/\/)/i.test(value) ? Config.SOCIAL_PLATFORMS[platformKey].prefix + value : value;
                    vCard += `URL;TYPE=${platformKey}:${fullUrl}\n`;
                }
            });
        }

        vCard += `END:VCARD`;
        return vCard;
    },
    downloadVcf() { const vcfData = this.getVCardString(); const blob = new Blob([vcfData], { type: 'text/vcard' }); const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = 'contact.vcf'; link.click(); URL.revokeObjectURL(url); },
    async downloadQrCode() {
        try {
            await Utils.loadScript(Config.SCRIPT_URLS.qrcode);
            const designId = await ShareManager.saveDesign();
            if (!designId) {
                throw new Error('فشل حفظ التصميم اللازم لإنشاء الرابط.');
            }

            const viewerPage = _isEnglishPage ? 'viewer-en.html' : 'viewer.html';
            const viewerUrl = new URL(viewerPage, window.location.href);
            viewerUrl.searchParams.set('id', designId);
            const finalUrl = viewerUrl.href;

            const container = DOMElements.qrCodeContainer;
            container.innerHTML = '';
            new QRCode(container, { text: finalUrl, width: 256, height: 256, correctLevel: QRCode.CorrectLevel.H });

            return new Promise((resolve, reject) => {
                setTimeout(() => {
                    const canvas = container.querySelector('canvas');
                    if (canvas) {
                        const link = document.createElement('a');
                        link.download = `qrcode-card-link-${designId}.png`;
                        link.href = canvas.toDataURL('image/png');
                        link.click();
                        resolve();
                    } else {
                        reject(new Error("حدث خطأ أثناء إنشاء QR Code. حاول مرة أخرى."));
                    }
                }, 100);
            });

        } catch (error) {
            console.error("Error generating shareable QR code:", error);
            let msg = "حدث خطأ. لم نتمكن من إنشاء رابط QR Code.";
            if (document.documentElement.lang === 'en') {
                msg = "An error occurred. We could not generate the QR Code link.";
            }
            if (error && error.message && error.message.trim() !== "") {
                msg += "\n\nError: " + error.message;
            }
            alert(msg);
            throw error;
        }
    },

    async downloadHtmlPackage() {
        try {
            UIManager.announce(document.documentElement.lang === 'en' ? "Preparing web package... Please wait" : "جاري تحضير ملف الويب... الرجاء الانتظار");

            const isEnglish = document.documentElement.lang === 'en';
            const viewerFile = isEnglish ? 'viewer-en.html' : 'viewer.html';

            // Fetch resources
            const [htmlRes, cssRes, jsRes, langRes] = await Promise.all([
                fetch(viewerFile),
                fetch('viewer.css'),
                fetch('viewer.js'),
                fetch('lang-switcher.js')
            ]);

            let htmlContent = await htmlRes.text();
            const cssContent = await cssRes.text();
            const jsContent = await jsRes.text();
            const langContent = await langRes.text();

            const state = StateManager.getStateObject();

            // Prepare injected scripts
            // We set window.cardData so viewer.js uses it instead of fetching
            const dataScript = `<script>window.cardData = ${JSON.stringify(state)};</script>`;

            // Replace CSS link
            htmlContent = htmlContent.replace(/<link[^>]*href="viewer\.css"[^>]*>/, `<style>\n${cssContent}\n</style>`);

            // Replace JS scripts
            // Replace lang-switcher
            htmlContent = htmlContent.replace(/<script[^>]*src="lang-switcher\.js"[^>]*>[\s\S]*?<\/script>/, `<script>\n${langContent}\n</script>`);

            // Replace viewer.js and inject data before it
            htmlContent = htmlContent.replace(/<script[^>]*src="viewer\.js"[^>]*>[\s\S]*?<\/script>/, `${dataScript}\n<script>\n${jsContent}\n</script>`);

            // Fix relative paths for base images if needed (optional optimization)
            // unique-id generation
            const filenameBase = (state.inputs && state.inputs['input-name'] ? state.inputs['input-name'] : 'card').replace(/[^a-z0-9]/gi, '_').toLowerCase();

            const blob = new Blob([htmlContent], { type: 'text/html' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${filenameBase}-full.html`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            UIManager.announce("تم تنزيل ملف الويب (HTML) بنجاح!");

        } catch (e) {
            console.error("HTML Export Error:", e);
            alert("حدث خطأ أثناء تصدير ملف الويب.");
        }
    }
};
const GalleryManager = {
    designs: [],
    init() { this.loadDesigns(); },
    loadDesigns() { this.designs = JSON.parse(localStorage.getItem(Config.GALLERY_STORAGE_KEY)) || []; },
    saveDesigns() { localStorage.setItem(Config.GALLERY_STORAGE_KEY, JSON.stringify(this.designs)); },
    async addCurrentDesign() {
        try {
            const state = StateManager.getStateObject();
            const thumbnail = await ExportManager.captureElement(DOMElements.cardFront, 0.5).then(canvas => canvas.toDataURL('image/jpeg', 0.5));
            this.designs.push({ name: (_isEnglishPage ? 'Design ' : 'تصميم ') + (this.designs.length + 1), timestamp: Date.now(), state, thumbnail });
            this.saveDesigns();
            UIManager.announce(i18nMain.designSaved);
        } catch (error) {
            console.error("Failed to add design to gallery:", error);
            alert(i18nMain.saveGalleryError);
            throw error;
        }
    },
    deleteDesign(index) { if (confirm(i18nMain.confirmDelete.replace('{name}', this.designs[index].name))) { this.designs.splice(index, 1); this.saveDesigns(); this.render(); } },
    loadDesignToEditor(index) { const design = this.designs[index]; if (design) { StateManager.applyState(design.state); UIManager.hideModal(DOMElements.galleryModal.overlay, DOMElements.buttons.showGallery); } },
    toggleRename(itemElement, index) {
        const nameSpan = itemElement.querySelector('.gallery-item-name-span'); const nameInput = itemElement.querySelector('.gallery-item-name-input'); const renameBtn = itemElement.querySelector('.gallery-rename-btn'); const icon = renameBtn.querySelector('i');
        if (nameInput.style.display === 'none') { nameSpan.style.display = 'none'; nameInput.style.display = 'block'; nameInput.value = this.designs[index].name; nameInput.focus(); icon.className = 'fas fa-save'; }
        else {
            const newName = nameInput.value.trim();
            if (newName) { this.designs[index].name = newName; this.saveDesigns(); nameSpan.textContent = newName; }
            nameSpan.style.display = 'block'; nameInput.style.display = 'none'; icon.className = 'fas fa-pencil-alt';
        }
    },
    render() {
        const grid = DOMElements.galleryModal.grid; grid.innerHTML = '';
        if (this.designs.length === 0) { const p = document.createElement('p'); p.textContent = i18nMain.galleryEmpty; grid.appendChild(p); return; }
        this.designs.forEach((design, index) => {
            const item = document.createElement('div'); item.className = 'gallery-item';
            const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.className = 'gallery-item-select'; checkbox.dataset.index = index; checkbox.onchange = () => this.updateSelectionState();
            const thumbnail = document.createElement('img'); thumbnail.src = design.thumbnail;
            thumbnail.alt = `معاينة لتصميم '${design.name}' المحفوظ`;
            thumbnail.className = 'gallery-thumbnail';
            const nameDiv = document.createElement('div'); nameDiv.className = 'gallery-item-name';
            const nameSpan = document.createElement('span'); nameSpan.className = 'gallery-item-name-span'; nameSpan.textContent = design.name;
            const nameInput = document.createElement('input'); nameInput.type = 'text'; nameInput.className = 'gallery-item-name-input'; nameInput.style.display = 'none'; nameInput.onkeydown = (e) => { if (e.key === 'Enter') this.toggleRename(item, index); };
            nameDiv.append(nameSpan, nameInput);
            const actionsDiv = document.createElement('div'); actionsDiv.className = 'gallery-item-actions';
            const createButton = (text, iconClass, clickHandler, isDanger = false) => {
                const button = document.createElement('button'); const icon = document.createElement('i'); icon.className = iconClass; icon.setAttribute('aria-hidden', 'true');
                if (text) { button.append(icon, ` ${text}`); } else { button.appendChild(icon); }
                button.onclick = clickHandler; if (isDanger) button.classList.add('danger'); return button;
            };
            const loadBtn = createButton(i18nMain.load, 'fas fa-edit', () => this.loadDesignToEditor(index));
            const renameBtn = createButton('', 'fas fa-pencil-alt', () => this.toggleRename(item, index)); renameBtn.classList.add('gallery-rename-btn');
            const deleteBtn = createButton('', 'fas fa-trash', () => this.deleteDesign(index), true);
            actionsDiv.append(loadBtn, renameBtn, deleteBtn);
            item.append(checkbox, thumbnail, nameDiv, actionsDiv);
            grid.appendChild(item);
        });
        this.updateSelectionState();
    },
    updateSelectionState() { const selectedCount = DOMElements.galleryModal.grid.querySelectorAll('.gallery-item-select:checked').length; DOMElements.galleryModal.downloadZipBtn.disabled = selectedCount === 0; },
    async downloadSelectedAsZip() {
        const selectedIndices = [...DOMElements.galleryModal.grid.querySelectorAll('.gallery-item-select:checked')].map(cb => parseInt(cb.dataset.index, 10));
        if (selectedIndices.length === 0) return;

        try {
            await Promise.all([
                Utils.loadScript(Config.SCRIPT_URLS.html2canvas),
                Utils.loadScript(Config.SCRIPT_URLS.jszip)
            ]);

            const originalState = StateManager.getStateObject();
            const zip = new JSZip();

            for (const index of selectedIndices) {
                const design = this.designs[index];
                StateManager.applyState(design.state, false);
                await new Promise(resolve => setTimeout(resolve, 50));
                const frontCanvas = await ExportManager.captureElement(DOMElements.cardFront);
                const backCanvas = await ExportManager.captureElement(DOMElements.cardBack);
                const frontBlob = await new Promise(resolve => frontCanvas.toBlob(resolve, 'image/png'));
                const backBlob = await new Promise(resolve => backCanvas.toBlob(resolve, 'image/png'));
                zip.file(`${design.name}_Front.png`, frontBlob);
                zip.file(`${design.name}_Back.png`, backBlob);
            }

            const content = await zip.generateAsync({ type: "blob" });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(content);
            link.download = "Business_Cards_Export.zip";
            link.click();
            URL.revokeObjectURL(link.href);
            StateManager.applyState(originalState, false);

        } catch (e) {
            console.error("ZIP export failed:", e);
            UIManager.announce(_isEnglishPage ? 'Error exporting ZIP file.' : "حدث خطأ أثناء تصدير الملف المضغوط.");
            alert(_isEnglishPage ? 'Failed to export ZIP. Problem loading components.' : "فشل تصدير الملف المضغوط. قد تكون هناك مشكلة في تحميل المكونات اللازمة.");
            throw e;
        }
    }
};

const ShareManager = {

    async captureAndUploadCard(element, purpose = null) {
        await Utils.loadScript(Config.SCRIPT_URLS.html2canvas);
        const canvas = await ExportManager.captureElement(element, 2);

        return new Promise((resolve, reject) => {
            canvas.toBlob(async (blob) => {
                if (!blob) {
                    return reject(new Error("فشل تحويل canvas إلى blob"));
                }
                try {
                    const file = new File([blob], "card-capture.png", { type: "image/png" });
                    const imageUrl = await UIManager.uploadImageToServer(file, purpose);
                    resolve(imageUrl);
                } catch (e) {
                    reject(e);
                }
            }, 'image/png', 0.95);
        });
    },

    createPublishedState(state) {
        const publishedState = JSON.parse(JSON.stringify(state || {}));
        // A published snapshot must stay one level deep. This prevents an
        // older snapshot from being nested again on every subsequent publish.
        delete publishedState.publishedState;
        delete publishedState.publishedAt;
        return publishedState;
    },

    async saveDesign(stateToSave = null) {
        const state = stateToSave || StateManager.getStateObject();
        try {
            const headers = { 'Content-Type': 'application/json' };

            let url = `${Config.API_BASE_URL}/api/save-design`;
            if (Config.currentDesignId) {
                url += `?id=${Config.currentDesignId}`;
            }

            const response = await Auth.apiFetchWithRefresh(url, {
                method: 'POST',
                headers: headers,
                body: JSON.stringify(state),
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                const errorMsg = errorData.error || 'Server responded with an error';
                throw new Error(errorMsg);
            }

            const result = await response.json();
            if (result.success && result.id) {
                Config.currentDesignId = result.id;
                localStorage.setItem('nfc:editingDesignId', result.id);
                return result.id;
            } else {
                throw new Error('Invalid response from server');
            }
        } catch (error) {
            console.error("Failed to save design:", error);
            UIManager.announce(i18nMain.saveFailed || 'فشل حفظ التصميم. حاول مرة أخرى.');
            return null;
        }
    },



    async performShare(url, title, text) {
        const shareData = { title, text, url };
        if (navigator.share) {
            try {
                await navigator.share(shareData);
            } catch (e) {
                console.error("Web Share API failed:", e);
                this.showFallback(url, text);
            }
        } else {
            this.showFallback(url, text);
        }
    },

    async shareCard() {
        // Check if user is logged in
        const isLoggedIn = (typeof Auth !== 'undefined' && Auth.isLoggedIn()) || !!localStorage.getItem('authUser');
        if (!isLoggedIn) {
            alert(i18nMain.loginRequired || 'يجب تسجيل الدخول أولاً لمشاركة بطاقتك. / You must be logged in to share your card.');
            return;
        }

        // Also target the mobile proxy button for visual feedback
        const mobileShareProxyBtn = document.querySelector('.mobile-action-btn[data-trigger-id="share-card-btn"]');

        UIManager.setButtonLoadingState(DOMElements.buttons.shareCard, true, i18nMain.capturing);
        if (mobileShareProxyBtn) UIManager.setButtonLoadingState(mobileShareProxyBtn, true, i18nMain.capturing || 'جاري التقاط الصورة...');

        let frontImageUrl, backImageUrl, shareState;

        try {
            // Deep clone state so modifications don't leak to auto-save
            shareState = JSON.parse(JSON.stringify(StateManager.getStateObject()));
            frontImageUrl = await this.captureAndUploadCard(DOMElements.cardFront, 'capturedFront');

            UIManager.setButtonLoadingState(DOMElements.buttons.shareCard, true, i18nMain.uploading);
            if (mobileShareProxyBtn) UIManager.setButtonLoadingState(mobileShareProxyBtn, true, i18nMain.uploading || 'جاري الرفع...');
            backImageUrl = await this.captureAndUploadCard(DOMElements.cardBack, 'capturedBack');

        } catch (error) {
            console.error("Card capture/upload failed:", error);
            alert(i18nMain.captureError);
            UIManager.setButtonLoadingState(DOMElements.buttons.shareCard, false);
            if (mobileShareProxyBtn) UIManager.setButtonLoadingState(mobileShareProxyBtn, false);
            return;
        }

        if (!shareState.imageUrls) shareState.imageUrls = {};
        shareState.imageUrls.capturedFront = frontImageUrl;
        shareState.imageUrls.capturedBack = backImageUrl;

        // Ask user if they want to display their design in the gallery
        shareState.sharedToGallery = await customConfirm(i18nMain.galleryPrompt);

        // Keep the editable state that produced the two captured images. Other
        // actions may save a newer draft later, but dashboard Edit must always
        // reconstruct the same card shown by those captured images.
        shareState.publishedAt = new Date().toISOString();
        shareState.publishedState = this.createPublishedState(shareState);

        UIManager.setButtonLoadingState(DOMElements.buttons.shareCard, true, i18nMain.generating);
        if (mobileShareProxyBtn) UIManager.setButtonLoadingState(mobileShareProxyBtn, true, i18nMain.generating || 'جاري الإنشاء...');

        // Save with authentication
        const designId = await this.saveDesign(shareState);

        UIManager.setButtonLoadingState(DOMElements.buttons.shareCard, false);
        if (mobileShareProxyBtn) UIManager.setButtonLoadingState(mobileShareProxyBtn, false);
        if (!designId) return;

        const viewerPage = _isEnglishPage ? 'viewer-en.html' : 'viewer.html';
        const viewerUrl = new URL(viewerPage, window.location.href);
        viewerUrl.searchParams.set('id', designId);

        this.performShare(viewerUrl.href, i18nMain.shareTitle, i18nMain.shareText);
    },

    async shareEditor() {
        UIManager.setButtonLoadingState(DOMElements.buttons.shareEditor, true);
        const designId = await this.saveDesign();
        UIManager.setButtonLoadingState(DOMElements.buttons.shareEditor, false);
        if (!designId) return;

        const editorUrl = new URL(window.location.href);
        editorUrl.searchParams.delete('id');
        editorUrl.searchParams.set('id', designId);
        // A shared editor link intentionally opens the latest draft. Normal
        // dashboard edit links omit this flag and restore the published card.
        editorUrl.searchParams.set('mode', 'draft');

        this.performShare(editorUrl.href, 'تعديل بطاقة العمل', 'استخدم هذا الرابط لتعديل تصميم بطاقة العمل.');
    },

    showFallback(url, text) {
        // إغلاق لوحات الجانب على الموبايل لضمان ظهور نافذة المشاركة
        if (typeof MobileUtils !== 'undefined' && MobileUtils.isMobile()) {
            MobileUtils.hidePanelBeforeModal();
        }
        DOMElements.shareModal.email.href = `mailto:?subject=My Business Card&body=${encodeURIComponent(text + '\n' + url)}`;
        DOMElements.shareModal.whatsapp.href = `https://api.whatsapp.com/send?text=${encodeURIComponent(text + '\n' + url)}`;
        DOMElements.shareModal.twitter.href = `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`;
        DOMElements.shareModal.copyLink.onclick = () => {
            Utils.copyTextToClipboard(url).then(success => {
                if (success) {
                    UIManager.announce(i18nMain.linkCopied || 'تم نسخ الرابط!');
                    if (typeof MobileUtils !== 'undefined' && MobileUtils.isMobile()) {
                        MobileUtils.showMobileToast((i18nMain.linkCopied || 'تم نسخ الرابط!') + ' 📋', 'success');
                    }
                }
            });
        };
        UIManager.showModal(DOMElements.shareModal.overlay);
    },

    async loadFromUrl() {
        const params = new URLSearchParams(window.location.search);
        const designId = params.get('id');

        if (params.has('collabId')) return false;

        if (designId) {
            if (Config.DEBUG_MODE) console.log('[DEBUG] loadFromUrl - designId from URL:', designId);
            
            try {
                const wantsDraft = params.get('mode') === 'draft';
                const designPath = wantsDraft
                    ? `/api/get-design/${designId}/draft`
                    : `/api/get-design/${designId}`;
                const fetchUrl = `${Config.API_BASE_URL}${designPath}`;
                const response = await fetch(fetchUrl, {
                    credentials: 'include',
                    cache: 'no-store'
                });
                
                if (Config.DEBUG_MODE) console.log('[DEBUG] API response status:', response.status);
                
                if (!response.ok) {
                    throw new Error(`Fetch failed with status ${response.status}`);
                }

                const result = await response.json();
                if (Config.DEBUG_MODE) console.log('[DEBUG] API result:', result);
                console.log("[ShareManager] API data received. Waiting for DOM readiness...");
                
                // Ensure DOM is ready before applying state
                await new Promise(resolve => {
                    if (document.readyState === 'loading') {
                        document.addEventListener('DOMContentLoaded', () => setTimeout(resolve, 100), { once: true });
                    } else {
                        setTimeout(resolve, 100);
                    }
                });

                const storedState = result.inputs ? result : (result.data || result);
                const hasPublishedState = storedState &&
                    storedState.publishedState &&
                    (storedState.publishedState.inputs || storedState.publishedState.dynamic);
                const state = !wantsDraft && hasPublishedState
                    ? storedState.publishedState
                    : storedState;

                if (state && (state.inputs || state.dynamic)) {
                    console.log(
                        hasPublishedState && !wantsDraft
                            ? "[ShareManager] DOM ready. Applying published design state..."
                            : "[ShareManager] DOM ready. Applying draft design state..."
                    );
                    Config.currentDesignId = designId;
                    localStorage.setItem('nfc:editingDesignId', designId);
                    StateManager.applyState(state, false);
                    return true;
                } else {
                    console.error("[ShareManager] Invalid structure in received design data.");
                    return false;
                }
            } catch (e) {
                console.error("[ShareManager] Critical failure in loadFromUrl:", e);
                UIManager.announce(_isEnglishPage ? 'Failed to load design from link.' : "فشل جلب التصميم من الرابط.");
                return false;
            } finally {
                // SECURITY & UX: We no longer strip the ID from the URL.
                // Keeping the ID allows for page refreshes and reliable editing sessions.
                console.log("[ShareManager] URL ID preserved for session stability.");
            }
        }
        return false;
    }
};

const EventManager = {
    makeListSortable(container, onSortCallback) {
        let draggedItem = null;
        container.addEventListener('dragstart', e => { draggedItem = e.target; setTimeout(() => e.target.classList.add('dragging'), 0); });
        container.addEventListener('dragend', e => { e.target.classList.remove('dragging'); });
        container.addEventListener('dragover', e => { e.preventDefault(); const afterElement = [...container.children].reduce((closest, child) => { const box = child.getBoundingClientRect(); const offset = e.clientY - box.top - box.height / 2; if (offset < 0 && offset > closest.offset) { return { offset: offset, element: child }; } else { return closest; } }, { offset: Number.NEGATIVE_INFINITY }).element; if (afterElement == null) { container.appendChild(draggedItem); } else { container.insertBefore(draggedItem, afterElement); } });
        container.addEventListener('drop', () => {
            if (onSortCallback) onSortCallback();
        });
    },

    moveElement(elementId, direction, step = 5) {
        const target = document.getElementById(elementId);
        if (!target) return;

        let x = parseFloat(target.getAttribute('data-x')) || 0;
        let y = parseFloat(target.getAttribute('data-y')) || 0;

        switch (direction) {
            case 'up': y -= step; break;
            case 'down': y += step; break;
            case 'left': x -= step; break;
            case 'right': x += step; break;
        }

        target.style.transform = `translate(${x}px, ${y}px)`;
        target.setAttribute('data-x', x);
        target.setAttribute('data-y', y);
    },

    bindEvents() {
        document.querySelectorAll('input, select, textarea').forEach(input => {
            const eventType = (input.type === 'range' || input.type === 'color' || input.type === 'checkbox') ? 'change' : 'input';

            input.addEventListener(eventType, () => {
                if (!StateManager.isApplyingState) {
                    if (input.id === 'logo-shadow-enabled') CardManager.updateLogoShadow();
                    if (input.id === 'photo-shadow-enabled') CardManager.updatePersonalPhotoShadow();
                }
            });

            input.addEventListener('input', () => {
                CardManager.updateElementFromInput(input);

                if (input.id.includes('photo-')) CardManager.updatePersonalPhotoStyles();
                if (input.id.includes('phone-btn')) CardManager.updatePhoneButtonStyles();

                if (input.id === 'logo-size' || input.id === 'logo-opacity') CardManager.updateLogoStyles();
                if (input.name === 'logo-align') CardManager.updateLogoAlignment();
                if (input.id === 'logo-bg-color') CardManager.updateLogoBackground();
                if (input.id.startsWith('logo-shadow-')) CardManager.updateLogoShadow();

                if (input.name === 'photo-align') CardManager.updatePersonalPhotoAlignment();
                if (input.id.startsWith('photo-shadow-') || input.id === 'photo-opacity') CardManager.updatePersonalPhotoStyles();

                if (input.id.startsWith('back-buttons')) CardManager.updateSocialButtonStyles();
                if (input.id.startsWith('social-text') || input.id.includes('-static-') || input.id.includes('-dynsocial_')) CardManager.updateSocialTextStyles();
                if (input.id.startsWith('input-') && !input.id.includes('-static-') && !input.id.includes('-dynsocial_')) CardManager.updateSocialLinks();
                if (input.id.startsWith('front-bg-') || input.id.startsWith('back-bg-')) CardManager.updateCardBackgrounds();
                if (input.id === 'qr-size') CardManager.updateQrCodeDisplay();

                if (input.id.startsWith('visibility-')) {
                    const key = input.id.replace('visibility-', '');
                    if (key === 'phones') CardManager.renderPhoneButtons();
                    else if (key === 'social') CardManager.updateSocialLinks();
                    else CardManager.renderCardContent();
                }

                const vCardFields = ['input-name_ar', 'input-name_en', 'input-tagline_ar', 'input-tagline_en', 'input-email', 'input-website'];
                if (vCardFields.includes(input.id)) CardManager.generateVCardQrDebounced();
                if (input.name.startsWith('placement-static-')) CardManager.updateSocialLinks();
            });
            input.addEventListener('focus', () => {
                let draggableId = input.dataset.updateTarget;
                if (draggableId === 'card-logo-img') draggableId = 'card-logo';
                const parentGroup = input.closest('.form-group');
                if (parentGroup && parentGroup.id.startsWith('form-group-static-')) draggableId = `social-link-static-${parentGroup.id.replace('form-group-static-', '')}`;
                if (draggableId) UIManager.highlightElement(draggableId, true);

            });
            input.addEventListener('blur', () => {
                let draggableId = input.dataset.updateTarget;
                if (draggableId === 'card-logo-img') draggableId = 'card-logo';
                const parentGroup = input.closest('.form-group');
                if (parentGroup && parentGroup.id.startsWith('form-group-static-')) draggableId = `social-link-static-${parentGroup.id.replace('form-group-static-', '')}`;
                if (draggableId) UIManager.highlightElement(draggableId, false);
            });
        });

        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey || e.metaKey) {
                if (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA') {
                    if (['z', 'y', 'a', 'c', 'x', 'v'].includes(e.key.toLowerCase())) {
                        if (e.key.toLowerCase() === 'z' || e.key.toLowerCase() === 'y') return;
                    }
                }

                if (e.key === 'z') {
                    e.preventDefault();
                    HistoryManager.undo();
                } else if (e.key === 'y') {
                    e.preventDefault();
                    HistoryManager.redo();
                }
            }
        });

        const previewBtn = DOMElements.buttons.previewMode;
        const exitPreviewBtn = DOMElements.buttons.exitPreview;
        if (previewBtn && exitPreviewBtn) {
            const togglePreview = () => {
                document.body.classList.toggle('preview-mode-active');
                const isActive = document.body.classList.contains('preview-mode-active');
                exitPreviewBtn.style.display = isActive ? 'flex' : 'none';
                previewBtn.setAttribute('aria-pressed', isActive.toString());
            };
            previewBtn.addEventListener('click', togglePreview);
            exitPreviewBtn.addEventListener('click', togglePreview);
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && document.body.classList.contains('preview-mode-active')) {
                    togglePreview();
                }
            });
        }

        const langToggleBtn = DOMElements.buttons.langToggle;
        if (langToggleBtn) {
            langToggleBtn.addEventListener('click', () => {
                // Use the global switchLanguage function from lang-switcher.js for page redirect
                if (typeof window.switchLanguage === 'function') {
                    const isArabic = document.documentElement.lang === 'ar' || !document.documentElement.lang;
                    const targetLang = isArabic ? 'en' : 'ar';
                    window.switchLanguage(targetLang);
                } else {
                    // Fallback: manual redirect if lang-switcher.js not loaded
                    const currentPage = window.location.pathname.split('/').pop() || 'editor.html';
                    if (currentPage === 'editor.html') {
                        window.location.href = 'editor-en.html';
                    } else if (currentPage === 'editor-en.html') {
                        window.location.href = 'editor.html';
                    }
                }
            });
        }

        // NEW: Download HTML
        const downloadHtmlBtn = document.querySelector('[data-trigger-id="download-html"]');
        if (downloadHtmlBtn) {
            downloadHtmlBtn.addEventListener('click', () => ExportManager.downloadHtmlPackage());
        }

        document.querySelectorAll('input[name="layout-select-visual"]').forEach(radio => {
            radio.addEventListener('change', (e) => {
                CardManager.applyLayout(e.target.value);
                const hiddenInput = document.getElementById('layout-select');
                if (hiddenInput) hiddenInput.value = e.target.value;
            });
        });

        document.querySelectorAll('.position-controls-grid').forEach(grid => {
            grid.querySelectorAll('.move-btn').forEach(button => {
                button.addEventListener('click', (e) => {
                    e.preventDefault();
                    const direction = button.dataset.direction;
                    let targetId = grid.dataset.targetId;
                    if (targetId && targetId.startsWith('form-group-static-')) targetId = `social-link-static-${targetId.replace('form-group-static-', '')}`;
                    if (targetId) EventManager.moveElement(targetId, direction);
                    else console.error("Missing targetId for move button.");
                });
            });
        });

        DOMElements.qrSourceRadios.forEach(radio => {
            radio.addEventListener('change', () => {
                const selectedValue = radio.value;
                DOMElements.qrUrlGroup.style.display = selectedValue === 'custom' ? 'block' : 'none';
                DOMElements.qrUploadGroup.style.display = selectedValue === 'upload' ? 'block' : 'none';
                DOMElements.qrAutoCardGroup.style.display = selectedValue === 'auto-card' ? 'block' : 'none';

                // Show customization only for auto-generated methods
                const customGroup = document.getElementById('qr-customization-group');
                if (customGroup) {
                    customGroup.style.display = (selectedValue === 'auto-card' || selectedValue === 'auto-vcard') ? 'block' : 'none';
                }

                CardManager.autoGeneratedQrDataUrl = null;
                if (selectedValue === 'auto-vcard') CardManager.generateVCardQr();
                else CardManager.updateQrCodeDisplay();
            });
        });

        // QR Customization Listeners
        const qrInputs = ['qr-dots-color', 'qr-bg-color', 'qr-dots-type', 'qr-corners-type', 'qr-use-logo'];
        qrInputs.forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                el.addEventListener('input', () => {
                    const source = document.querySelector('input[name="qr-source"]:checked')?.value;
                    if (source === 'auto-vcard') CardManager.generateVCardQrDebounced();
                    // For auto-card, we might want a manual update or debounced. 
                    // Since auto-card requires saving design, we don't want to spam it.
                    // But maybe we can update preview? No, generateCardLinkQr does everything.
                    // So for auto-card, user has to click "Generate/Update".
                    // But for auto-vcard it's fast.
                });
            }
        });

        document.querySelectorAll('input[name^="placement-"]').forEach(radio => {
            radio.addEventListener('change', () => {
                // Skip position reset during state restoration
                if (StateManager.isApplyingState) {
                    CardManager.renderCardContent();
                    return;
                }
                const elementName = radio.name.replace('placement-', '');
                let elementToReset;

                const staticMatch = elementName.match(/static-(.*)/);
                if (staticMatch) {
                    elementToReset = document.getElementById(`social-link-static-${staticMatch[1]}`);
                } else if (elementName.startsWith('dynsocial_')) {
                    elementToReset = document.getElementById(`social-link-${elementName.replace(/[^a-zA-Z0-9-]/g, '-')}`);
                } else {
                    const elementsMap = { logo: DOMElements.draggable.logo, photo: DOMElements.draggable.photo, name: DOMElements.draggable.name, tagline: DOMElements.draggable.tagline, qr: DOMElements.draggable.qr };
                    elementToReset = elementsMap[elementName];
                }

                if (elementToReset) {
                    elementToReset.style.transform = 'translate(0px, 0px)';
                    elementToReset.setAttribute('data-x', '0');
                    elementToReset.setAttribute('data-y', '0');
                }
                CardManager.renderCardContent();
            });
        });

        DOMElements.buttons.generateAutoQr.addEventListener('click', () => {
            if (typeof gtag === 'function') { gtag('event', 'generate_qr_code'); }
            CardManager.generateCardLinkQr();
        });

        DOMElements.fileInputs.logo.addEventListener('change', e => UIManager.handleImageUpload(e, {
            maxSizeMB: Config.MAX_LOGO_SIZE_MB,
            errorEl: DOMElements.errors.logoUpload,
            spinnerEl: DOMElements.spinners.logo,
            onSuccess: (imageUrl) => {
                DOMElements.draggable.logoImg.src = imageUrl;
                const inputLogo = document.getElementById('input-logo');
                if (inputLogo) {
                    inputLogo.value = imageUrl;
                    inputLogo.dispatchEvent(new Event('input', { bubbles: true }));
                }
                DOMElements.previews.logo.src = imageUrl;
                UIManager.updateFavicon(imageUrl);
            },
            cropOptions: { aspectRatio: NaN }, // Free crop for logos
            purpose: 'logo'
        }));

        const logoUploadZone = document.getElementById('lp-upload-zone-click');
        if (logoUploadZone && DOMElements.fileInputs.logo) {
            logoUploadZone.addEventListener('click', (e) => {
                if (!e.target.closest('label') && !e.target.closest('input')) {
                    DOMElements.fileInputs.logo.click();
                }
            });
            UIManager.setupDragDrop('lp-upload-zone-click', 'input-logo-upload');
        }

        DOMElements.fileInputs.photo.addEventListener('change', e => UIManager.handleImageUpload(e, {
            maxSizeMB: Config.MAX_LOGO_SIZE_MB,
            errorEl: DOMElements.errors.photoUpload,
            spinnerEl: DOMElements.spinners.photo,
            onSuccess: imageUrl => {
                CardManager.personalPhotoUrl = imageUrl;
                DOMElements.photoControls.url.value = imageUrl;
                DOMElements.photoControls.url.dispatchEvent(new Event('input', { bubbles: true }));
            },
            cropOptions: { aspectRatio: 1 / 1 }, // Square crop for personal photos
            purpose: 'photo'
        }));

        const photoUploadZone = document.getElementById('lp-photo-upload-zone-click') || document.getElementById('lp-upload-zone-photo');
        if (photoUploadZone && DOMElements.fileInputs.photo) {
            const photoZoneId = photoUploadZone.id;
            photoUploadZone.addEventListener('click', (e) => {
                if (!e.target.closest('label') && !e.target.closest('input')) {
                    DOMElements.fileInputs.photo.click();
                }
            });
            UIManager.setupDragDrop(photoZoneId, 'input-photo-upload');
        }

        DOMElements.fileInputs.frontBg.addEventListener('change', e => UIManager.handleImageUpload(e, {
            maxSizeMB: Config.MAX_BG_SIZE_MB, errorEl: DOMElements.errors.logoUpload, spinnerEl: DOMElements.spinners.frontBg,
            onSuccess: url => {
                CardManager.frontBgImageUrl = url; DOMElements.buttons.removeFrontBg.style.display = 'block';
                CardManager.updateCardBackgrounds();
            },
            cropOptions: { skipCrop: true },
            purpose: 'front_bg'
        }));

        DOMElements.fileInputs.backBg.addEventListener('change', e => UIManager.handleImageUpload(e, {
            maxSizeMB: Config.MAX_BG_SIZE_MB, errorEl: DOMElements.errors.logoUpload, spinnerEl: DOMElements.spinners.backBg,
            onSuccess: url => {
                CardManager.backBgImageUrl = url; DOMElements.buttons.removeBackBg.style.display = 'block';
                CardManager.updateCardBackgrounds();
            },
            cropOptions: { skipCrop: true },
            purpose: 'back_bg'
        }));

        DOMElements.fileInputs.qrCode.addEventListener('change', e => UIManager.handleImageUpload(e, {
            maxSizeMB: Config.MAX_LOGO_SIZE_MB, errorEl: DOMElements.errors.qrUpload, spinnerEl: DOMElements.spinners.qr,
            onSuccess: imageUrl => {
                CardManager.qrCodeImageUrl = imageUrl; DOMElements.qrImageUrlInput.value = imageUrl;
                CardManager.updateQrCodeDisplay();
            },
            cropOptions: { skipCrop: true },
            purpose: 'qr'
        }));

        DOMElements.themeGallery.addEventListener('click', (e) => {
            const thumbnail = e.target.closest('.theme-thumbnail');
            if (thumbnail) {
                const themeKey = thumbnail.dataset.themeKey;
                CardManager.applyTheme(themeKey);
            }
        });

        DOMElements.buttons.addPhone.addEventListener('click', () => { CardManager.createPhoneInput(); CardManager.renderPhoneButtons(); });
        DOMElements.buttons.addSocial.addEventListener('click', () => CardManager.addSocialLink());
        DOMElements.buttons.reset.addEventListener('click', () => StateManager.reset());
        DOMElements.layoutSelect.addEventListener('change', e => CardManager.applyLayout(e.target.value));


        DOMElements.buttons.showGallery.addEventListener('click', (e) => {
            GalleryManager.render();
            UIManager.showModal(DOMElements.galleryModal.overlay, e.currentTarget);
        });

        DOMElements.buttons.saveToGallery.addEventListener('click', async (e) => {
            const btn = e.currentTarget;
            UIManager.setButtonLoadingState(btn, true);
            try { await GalleryManager.addCurrentDesign(); }
            finally { UIManager.setButtonLoadingState(btn, false); }
        });

        DOMElements.buttons.shareEditor.addEventListener('click', () => {
            if (typeof gtag === 'function') { gtag('event', 'share_editor'); }
            ShareManager.shareEditor();
        });
        
        if (DOMElements.buttons.startCollab) {
            DOMElements.buttons.startCollab.addEventListener('click', () => {
                if (typeof CollaborationManager !== 'undefined') {
                    CollaborationManager.startSession();
                }
            });
        }

        const toolsMenuBtn = document.getElementById('tools-menu-btn');
        const toolsMenu = document.getElementById('tools-dropdown-menu');
        if (toolsMenuBtn && toolsMenu) {
            toolsMenuBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                toolsMenu.classList.toggle('show');
            });
            window.addEventListener('click', () => toolsMenu.classList.remove('show'));
        }

        const navigateToTarget = (e, fallback) => {
            e.preventDefault();
            e.stopPropagation();
            const targetId = e.currentTarget.dataset.inputTargetId || fallback;
            UIManager.navigateToAndHighlight(targetId);
        };

        if (DOMElements.draggable.logo) DOMElements.draggable.logo.addEventListener('click', (e) => navigateToTarget(e, 'logo-drop-zone'));
        if (DOMElements.draggable.photo) DOMElements.draggable.photo.addEventListener('click', (e) => navigateToTarget(e, 'photo-controls-fieldset'));
        if (DOMElements.draggable.name) DOMElements.draggable.name.addEventListener('click', (e) => navigateToTarget(e, 'name-accordion'));
        if (DOMElements.draggable.tagline) DOMElements.draggable.tagline.addEventListener('click', (e) => navigateToTarget(e, 'tagline-accordion'));
        if (DOMElements.draggable.qr) DOMElements.draggable.qr.addEventListener('click', (e) => navigateToTarget(e, 'qr-code-accordion'));

        DOMElements.buttons.togglePhone.addEventListener('input', () => { CardManager.updatePhoneButtonsVisibility(); });

        DOMElements.buttons.toggleSocial.addEventListener('input', () => {
            CardManager.updateSocialLinksVisibility();
            CardManager.updateSocialButtonStyles();
            CardManager.updateSocialTextStyles();
        });

        if (DOMElements.buttons.toggleMasterSocial) {
            DOMElements.buttons.toggleMasterSocial.addEventListener('input', () => {
                CardManager.handleMasterSocialToggle();
            });
        }

        const phoneTextControlsList = [...DOMElements.phoneTextControls.layoutRadios, DOMElements.phoneTextControls.size, DOMElements.phoneTextControls.color, DOMElements.phoneTextControls.font];
        phoneTextControlsList.forEach(control => {
            control.addEventListener('input', () => { CardManager.updatePhoneTextStyles(); });
        });

        DOMElements.buttons.removeFrontBg.addEventListener('click', () => {
            CardManager.frontBgImageUrl = null;
            DOMElements.fileInputs.frontBg.value = '';
            DOMElements.frontBgOpacity.value = 1;
            DOMElements.frontBgOpacity.dispatchEvent(new Event('input'));
            DOMElements.buttons.removeFrontBg.style.display = 'none';
            CardManager.updateCardBackgrounds();
        });

        DOMElements.buttons.removeBackBg.addEventListener('click', () => {
            CardManager.backBgImageUrl = null;
            DOMElements.fileInputs.backBg.value = '';
            DOMElements.backBgOpacity.value = 1;
            DOMElements.backBgOpacity.dispatchEvent(new Event('input'));
            DOMElements.buttons.removeBackBg.style.display = 'none';
            CardManager.updateCardBackgrounds();
        });

        DOMElements.buttons.downloadOptions.addEventListener('click', (e) => {
            e.stopPropagation();
            DOMElements.downloadMenu.classList.toggle('show');
        });

        window.addEventListener('click', (e) => {
            if (!DOMElements.downloadContainer.contains(e.target)) {
                DOMElements.downloadMenu.classList.remove('show');
            }
        });

        DOMElements.buttons.downloadPngFront.addEventListener('click', (e) => {
            if (typeof gtag === 'function') { gtag('event', 'save_card', { 'file_type': 'png_front' }); }
            ExportManager.pendingExportTarget = 'front'; UIManager.showModal(DOMElements.exportModal.overlay, e.currentTarget);
        });

        DOMElements.buttons.downloadPngBack.addEventListener('click', (e) => {
            if (typeof gtag === 'function') { gtag('event', 'save_card', { 'file_type': 'png_back' }); }
            ExportManager.pendingExportTarget = 'back'; UIManager.showModal(DOMElements.exportModal.overlay, e.currentTarget);
        });

        DOMElements.buttons.downloadPdf.addEventListener('click', async (e) => {
            if (typeof gtag === 'function') { gtag('event', 'save_card', { 'file_type': 'pdf' }); }
            const button = e.currentTarget;
            UIManager.setButtonLoadingState(button, true);
            try { await ExportManager.downloadPdf(); }
            catch (error) { }
            finally { UIManager.setButtonLoadingState(button, false); }
        });

        DOMElements.buttons.downloadVcf.addEventListener('click', () => {
            if (typeof gtag === 'function') { gtag('event', 'save_card', { 'file_type': 'vcf' }); }
            ExportManager.downloadVcf();
        });

        DOMElements.buttons.downloadQrCode.addEventListener('click', async (e) => {
            if (typeof gtag === 'function') { gtag('event', 'save_card', { 'file_type': 'qr_code_link' }); }
            const button = e.currentTarget;
            UIManager.setButtonLoadingState(button, true);
            try { await ExportManager.downloadQrCode(); }
            catch (error) { }
            finally { UIManager.setButtonLoadingState(button, false); }
        });

        DOMElements.buttons.backToTop.addEventListener('click', () => { window.scrollTo({ top: 0, behavior: 'smooth' }); });
        const handleScroll = () => { window.scrollY > 300 ? DOMElements.buttons.backToTop.classList.add('visible') : DOMElements.buttons.backToTop.classList.remove('visible'); };
        window.addEventListener('scroll', Utils.debounce(handleScroll, 100));
        DOMElements.exportModal.overlay.addEventListener('click', (e) => { if (e.target === DOMElements.exportModal.overlay) UIManager.hideModal(DOMElements.exportModal.overlay); });
        DOMElements.exportModal.closeBtn.addEventListener('click', () => UIManager.hideModal(DOMElements.exportModal.overlay));

        DOMElements.exportModal.confirmBtn.addEventListener('click', async () => {
            try {
                const options = { format: DOMElements.exportModal.format.value, quality: DOMElements.exportModal.quality.value / 100, scale: parseFloat(DOMElements.exportModal.scaleContainer.querySelector('.selected').dataset.scale) };
                await ExportManager.downloadElement(options);
            } catch (error) { alert("فشل تحميل أداة الحفظ. يرجى المحاولة مرة أخرى."); }
        });

        DOMElements.exportModal.format.addEventListener('input', () => { DOMElements.exportModal.qualityGroup.style.display = DOMElements.exportModal.format.value === 'jpeg' ? 'block' : 'none'; });
        DOMElements.exportModal.quality.addEventListener('input', () => { DOMElements.exportModal.qualityValue.textContent = DOMElements.exportModal.quality.value; });
        DOMElements.exportModal.scaleContainer.addEventListener('click', e => { if (e.target.classList.contains('scale-btn')) { DOMElements.exportModal.scaleContainer.querySelector('.selected').classList.remove('selected'); e.target.classList.add('selected'); } });

        DOMElements.buttons.saveToGallery.addEventListener('click', async (e) => {
            const button = e.currentTarget;
            UIManager.setButtonLoadingState(button, true, 'جاري الحفظ...');
            try { await GalleryManager.addCurrentDesign(); }
            finally { UIManager.setButtonLoadingState(button, false); }
        });
        DOMElements.buttons.showGallery.addEventListener('click', (e) => { GalleryManager.render(); UIManager.showModal(DOMElements.galleryModal.overlay, e.currentTarget); });

        DOMElements.galleryModal.closeBtn.addEventListener('click', () => UIManager.hideModal(DOMElements.galleryModal.overlay));
        DOMElements.galleryModal.selectAllBtn.addEventListener('click', () => DOMElements.galleryModal.grid.querySelectorAll('.gallery-item-select').forEach(cb => { cb.checked = true; cb.closest('.gallery-item').classList.add('selected'); GalleryManager.updateSelectionState(); }));
        DOMElements.galleryModal.deselectAllBtn.addEventListener('click', () => DOMElements.galleryModal.grid.querySelectorAll('.gallery-item-select').forEach(cb => { cb.checked = false; cb.closest('.gallery-item').classList.remove('selected'); GalleryManager.updateSelectionState(); }));

        DOMElements.galleryModal.downloadZipBtn.addEventListener('click', async (e) => {
            const button = e.currentTarget;
            UIManager.setButtonLoadingState(button, true, 'جاري التجهيز...');
            try { await GalleryManager.downloadSelectedAsZip(); }
            finally { StateManager.applyState(StateManager.getStateObject(), false); UIManager.setButtonLoadingState(button, false); }
        });

        DOMElements.galleryModal.grid.addEventListener('change', e => { if (e.target.classList.contains('gallery-item-select')) { e.target.closest('.gallery-item').classList.toggle('selected', e.target.checked); GalleryManager.updateSelectionState(); } });
        DOMElements.shareModal.closeBtn.addEventListener('click', () => UIManager.hideModal(DOMElements.shareModal.overlay));
        DOMElements.shareModal.overlay.addEventListener('click', e => { if (e.target === DOMElements.shareModal.overlay) UIManager.hideModal(DOMElements.shareModal.overlay); });

        // Initialize new AI Suggestion Panel (handles its own events)
        if (typeof SuggestionEngine !== 'undefined' && SuggestionEngine.init) {
            SuggestionEngine.init();
        }

        DOMElements.buttons.undoBtn.addEventListener('click', () => HistoryManager.undo());
        DOMElements.buttons.redoBtn.addEventListener('click', () => HistoryManager.redo());

        DOMElements.helpModal.closeBtn.addEventListener('click', () => UIManager.hideModal(DOMElements.helpModal.overlay));
        DOMElements.helpModal.overlay.addEventListener('click', e => {
            if (e.target === DOMElements.helpModal.overlay) UIManager.hideModal(DOMElements.helpModal.overlay);
        });

        DOMElements.helpModal.nav.addEventListener('click', (e) => {
            const button = e.target.closest('.help-tab-btn');
            if (!button) return;

            DOMElements.helpModal.nav.querySelectorAll('.help-tab-btn').forEach(btn => btn.classList.remove('active'));
            DOMElements.helpModal.panes.forEach(pane => pane.classList.remove('active'));

            button.classList.add('active');
            const targetPane = document.getElementById(button.dataset.tabTarget);
            if (targetPane) {
                targetPane.classList.add('active');
            }
        });
    }
};

const App = {
    async init() {
        // Initialize Proxy State
        if (window.StateManagerProxy) {
            window.StateManagerProxy.init(Config.defaultState);
        }

        Object.assign(DOMElements, {
            cardFront: document.getElementById('card-front-preview'),
            cardBack: document.getElementById('card-back-preview'),
            cardFrontContent: document.getElementById('card-front-content'),
            cardBackContent: document.getElementById('card-back-content'),
            phoneNumbersContainer: document.getElementById('phone-numbers-container'),
            cardsWrapper: document.getElementById('cards-wrapper'),

            draggable: {
                logo: document.getElementById('card-logo'),
                logoImg: document.getElementById('card-logo-img'),
                photo: document.getElementById('card-personal-photo-wrapper'),
                name: document.getElementById('card-name'),
                tagline: document.getElementById('card-tagline'),
                qr: document.getElementById('qr-code-wrapper')
            },

            photoControls: {
                url: document.getElementById('input-photo-url'),
                shapeRadios: document.querySelectorAll('input[name="photo-shape"]'),
                borderColor: document.getElementById('photo-border-color'),
                borderWidth: document.getElementById('photo-border-width'),
            },

            themeGallery: document.getElementById('theme-gallery'),
            layoutSelect: document.getElementById('layout-select'), liveAnnouncer: document.getElementById('live-announcer'), saveToast: document.getElementById('save-toast'),
            nameInput: document.getElementById(document.documentElement.lang === 'en' ? 'input-name_en' : 'input-name_ar'),
            taglineInput: document.getElementById(document.documentElement.lang === 'en' ? 'input-tagline_en' : 'input-tagline_ar'),
            qrImageUrlInput: document.getElementById('input-qr-url'),
            qrCodeContainer: document.getElementById('qrcode-container'),
            qrCodeTempGenerator: document.getElementById('qr-code-temp-generator'),
            qrSourceRadios: document.querySelectorAll('input[name="qr-source"]'),
            qrUrlGroup: document.getElementById('qr-url-group'),
            qrUploadGroup: document.getElementById('qr-upload-group'),
            qrAutoCardGroup: document.getElementById('qr-auto-card-group'),
            qrSizeSlider: document.getElementById('qr-size'),
            phoneBtnBgColor: document.getElementById('phone-btn-bg-color'), phoneBtnTextColor: document.getElementById('phone-btn-text-color'), phoneBtnFontSize: document.getElementById('phone-btn-font-size'), phoneBtnFont: document.getElementById('phone-btn-font'), backButtonsBgColor: document.getElementById('back-buttons-bg-color'), backButtonsTextColor: document.getElementById('back-buttons-text-color'), backButtonsFont: document.getElementById('back-buttons-font'),
            frontBgOpacity: document.getElementById('front-bg-opacity'), backBgOpacity: document.getElementById('back-bg-opacity'), phoneBtnPadding: document.getElementById('phone-btn-padding'), backButtonsSize: document.getElementById('back-buttons-size'),
            nameColor: document.getElementById('name-color'), nameFontSize: document.getElementById('name-font-size'), nameFont: document.getElementById('name-font'),
            taglineColor: document.getElementById('tagline-color'), taglineFontSize: document.getElementById('tagline-font-size'), taglineFont: document.getElementById('tagline-font'),
            social: { input: document.getElementById('social-media-input'), container: document.getElementById('dynamic-social-links-container'), typeSelect: document.getElementById('social-media-type') },
            fileInputs: { logo: document.getElementById('input-logo-upload'), photo: document.getElementById('input-photo-upload'), frontBg: document.getElementById('front-bg-upload'), backBg: document.getElementById('back-bg-upload'), qrCode: document.getElementById('input-qr-upload') },
            previews: { logo: document.getElementById('logo-preview'), photo: document.getElementById('photo-preview') },
            errors: { logoUpload: document.getElementById('logo-upload-error'), photoUpload: document.getElementById('photo-upload-error'), qrUpload: document.getElementById('qr-upload-error') },
            spinners: { logo: document.getElementById('logo-spinner'), photo: document.getElementById('photo-spinner'), frontBg: document.getElementById('front-bg-spinner'), backBg: document.getElementById('back-bg-spinner'), qr: document.getElementById('qr-spinner') },
            sounds: { success: document.getElementById('audio-success'), error: document.getElementById('audio-error') },
            phoneTextControls: { container: document.getElementById('phone-text-controls'), layoutRadios: document.querySelectorAll('input[name="phone-text-layout"]'), size: document.getElementById('phone-text-size'), color: document.getElementById('phone-text-color'), font: document.getElementById('phone-text-font'), },
            socialTextControls: { container: document.getElementById('social-text-controls'), size: document.getElementById('social-text-size'), color: document.getElementById('social-text-color'), font: document.getElementById('social-text-font'), },
            socialControlsWrapper: document.getElementById('social-controls-wrapper'),
            exportLoadingOverlay: document.getElementById('export-loading-overlay'),
            exportModal: { overlay: document.getElementById('export-modal-overlay'), closeBtn: document.getElementById('export-modal-close'), confirmBtn: document.getElementById('confirm-export-btn'), format: document.getElementById('export-format'), qualityGroup: document.getElementById('export-quality-group'), quality: document.getElementById('export-quality'), qualityValue: document.getElementById('export-quality-value'), scaleContainer: document.querySelector('.scale-buttons') },
            galleryModal: { overlay: document.getElementById('gallery-modal-overlay'), closeBtn: document.getElementById('gallery-modal-close'), grid: document.getElementById('gallery-grid'), selectAllBtn: document.getElementById('gallery-select-all'), deselectAllBtn: document.getElementById('gallery-deselect-all'), downloadZipBtn: document.getElementById('gallery-download-zip') },
            shareModal: { overlay: document.getElementById('share-fallback-modal-overlay'), closeBtn: document.getElementById('share-fallback-modal-close'), email: document.getElementById('share-email'), whatsapp: document.getElementById('share-whatsapp'), twitter: document.getElementById('share-twitter'), copyLink: document.getElementById('share-copy-link') },
            downloadContainer: document.querySelector('.download-container'),
            downloadMenu: document.getElementById('download-menu'),
            helpModal: {
                overlay: document.getElementById('help-modal-overlay'),
                closeBtn: document.getElementById('help-modal-close'),
                nav: document.querySelector('.help-tabs-nav'),
                panes: document.querySelectorAll('.help-tab-pane')
            },

            buttons: {
                addPhone: document.getElementById('add-phone-btn'), addSocial: document.getElementById('add-social-btn'),
                removeFrontBg: document.getElementById('remove-front-bg-btn'), removeBackBg: document.getElementById('remove-back-bg-btn'),
                backToTop: document.getElementById('back-to-top-btn'),
                togglePhone: document.getElementById('toggle-phone-buttons'),
                toggleSocial: document.getElementById('toggle-social-buttons'),
                toggleMasterSocial: document.getElementById('toggle-master-social'),
                saveToGallery: document.getElementById('save-to-gallery-btn'),
                showGallery: document.getElementById('show-gallery-btn'),
                saveShare: document.getElementById('save-share-btn'),
                shareEditor: document.getElementById('share-editor-btn'),
                startCollab: document.getElementById('start-collab-btn'),
                downloadOptions: document.getElementById('download-options-btn'),
                downloadPngFront: document.getElementById('download-png-front'),
                downloadPngBack: document.getElementById('download-png-back'),
                downloadPdf: document.getElementById('download-pdf'),
                downloadVcf: document.getElementById('download-vcf'),
                downloadQrCode: document.getElementById('download-qrcode'),
                reset: document.getElementById('reset-design-btn'),
                undoBtn: document.getElementById('undo-btn'),
                redoBtn: document.getElementById('redo-btn'),
                generateAutoQr: document.getElementById('generate-auto-qr-btn'),
                previewMode: document.getElementById('preview-mode-btn'),
                exitPreview: document.getElementById('exit-preview-btn'),
                langToggle: document.getElementById('lang-toggle-btn'),
            }
        });

        Object.values(DOMElements.draggable).forEach(el => {
            if (el && el.id !== 'card-logo-img') {
                el.classList.add('draggable-on-card');
                const hint = document.createElement('i');
                hint.className = 'fas fa-arrows-alt dnd-hover-hint';
                el.appendChild(hint);
            }
        });

        // 1. UI Build & Core Discovery
        ImageCropper.init();
        UIManager.init();
        UIManager.fetchAndPopulateBackgrounds();
        
        console.log('[App] Core components discovery:', {
            frontBgOpacity: !!DOMElements.frontBgOpacity,
            backBgOpacity: !!DOMElements.backBgOpacity
        });

        // 2. Event Binding (Crucial to have listeners before applying state)
        EventManager.bindEvents();

        // 3. Design Identity Recovery (Priority: URL > LocalStorage)
        const urlParams = new URLSearchParams(window.location.search);
        const urlDesignId = urlParams.get('id');

        if (urlDesignId) {
            console.log(`[App] URL 'id' detected: ${urlDesignId}. Prioritizing server load.`);
        } else if (!Config.currentDesignId) {
            Config.currentDesignId = localStorage.getItem('nfc:editingDesignId') || null;
            if (Config.currentDesignId) {
                console.log(`[App] Recovered design identity from localStorage: ${Config.currentDesignId}`);
            }
        }

        const loadedFromUrl = await ShareManager.loadFromUrl();
        
        // 4. Full State Application
        if (loadedFromUrl) {
            console.log("[App] Design successfully loaded from URL.");
            HistoryManager.pushState(StateManager.getStateObject());
            UIManager.announce(i18nMain.designLoaded);
        } else if (urlDesignId) {
            // CRITICAL FIX: If a URL ID was provided but load failed, do NOT fall back to storage.
            // This prevents loading a different previous card by mistake.
            console.warn("[App] Failed to load the specific design from URL. Loading defaults to prevent data confusion.");
            StateManager.applyState(Config.defaultState, false);
            HistoryManager.pushState(Config.defaultState);
            UIManager.announce(_isEnglishPage ? 'Could not load the requested design.' : "تعذر تحميل التصميم المطلوب.");
        } else if (!CollaborationManager.isActive) {
            // FALLBACK: Only use storage if no specific ID was requested via URL
            const loadedFromStorage = StateManager.load();
            if (loadedFromStorage) {
                console.log("[App] Design restored from local storage.");
                HistoryManager.pushState(StateManager.getStateObject());
                UIManager.announce(i18nMain.designRestored);
            } else {
                console.log("[App] No saved design found. Loading defaults...");
                StateManager.applyState(Config.defaultState, false);
                HistoryManager.pushState(Config.defaultState);
                UIManager.announce(i18nMain.defaultLoaded);
            }
        }

        // 5. Final Sub-Manager initialization
        GalleryManager.init();
        CollaborationManager.init();

        const initialQrSource = document.querySelector('input[name="qr-source"]:checked')?.value || 'auto-card';
        DOMElements.qrUrlGroup.style.display = initialQrSource === 'custom' ? 'block' : 'none';
        DOMElements.qrUploadGroup.style.display = initialQrSource === 'upload' ? 'block' : 'none';
        DOMElements.qrAutoCardGroup.style.display = initialQrSource === 'auto-card' ? 'block' : 'none';


        CardManager.updatePhoneButtonsVisibility();
        CardManager.updatePhoneTextStyles();
        DragManager.init();

        UIManager.announce("محرر بطاقة الأعمال جاهز للاستخدام.");

        // Initialize Undo/Redo buttons
        if (DOMElements.buttons.undoBtn) {
            DOMElements.buttons.undoBtn.addEventListener('click', () => {
                HistoryManager.undo();
                // Update autosave indicator if available
                if (window.updateAutoSaveIndicator) window.updateAutoSaveIndicator('saving');
                setTimeout(() => { if (window.updateAutoSaveIndicator) window.updateAutoSaveIndicator('saved'); }, 500);
            });
        }
        if (DOMElements.buttons.redoBtn) {
            DOMElements.buttons.redoBtn.addEventListener('click', () => {
                HistoryManager.redo();
                // Update autosave indicator if available
                if (window.updateAutoSaveIndicator) window.updateAutoSaveIndicator('saving');
                setTimeout(() => { if (window.updateAutoSaveIndicator) window.updateAutoSaveIndicator('saved'); }, 500);
            });
        }

        // Hook into StateManager to push history on changes
        const originalSaveDebounced = StateManager.saveDebounced;
        StateManager.saveDebounced = function () {
            HistoryManager.pushState(StateManager.getStateObject());
            originalSaveDebounced.apply(this, arguments);
            // Update indicator
            if (window.updateAutoSaveIndicator) window.updateAutoSaveIndicator('saving');
            setTimeout(() => { if (window.updateAutoSaveIndicator) window.updateAutoSaveIndicator('saved'); }, 1000);
        };

        setInterval(() => {
            if (HistoryManager.currentIndex >= 0) {
                StateManager.saveDebounced();
            }
        }, 30000);
    }
};
document.addEventListener('DOMContentLoaded', () => App.init());
